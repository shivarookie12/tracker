import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { LogoutComponent } from './logout/logout.component';
import { AuthService } from './auth.service';
import { AuthGuard } from './auth.guard';
import { LessonComponent } from './lesson/lesson.component';




@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    LogoutComponent,
    LessonComponent,


  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    RouterModule.forRoot([
      {
        path: 'login',
        component: LoginComponent
      },
      {
        path: 'logout',
        component: LogoutComponent
      },
      {
        path: 'home',
        component:HomeComponent ,
        canActivate: [AuthGuard],
        children: [
          {
          path:  'updateLesson',
          component:LessonComponent
          },
          {
          path:  'viewProject',
          component:LoginComponent
          },
          {
          path:  'inSearch',
          component:LoginComponent
          }
          ]
          
          
      },
      {
        path: '',
        component: LoginComponent
      }
    ])
  ],
  providers: [AuthService,AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class AuthService {
private loggedInStatus : boolean;
  constructor(private http : HttpClient) { }
  getUserDetails(username, password) {
    // post these details to API server return user info if correct
    return this.http.post("http://localhost/api/selectUser.php/",{'id':username,'pass':password})  
  }
  setLoggedIn(value: boolean) {
    this.loggedInStatus = value
    
  }
  get isLoggedIn() {
    return this.loggedInStatus
  }
}
